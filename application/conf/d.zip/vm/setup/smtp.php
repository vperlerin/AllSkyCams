<?php
 
// SMTP
define('SMTP_HOST','smtp.gmail.com');
define('SMTP_USER','amsmeteors@gmail.com');
define('SMTP_PWD','m3t30r1911!');
define('SMTPSecure','tls');
define('SMTP_TLS_PORT','587');
define('SMTP_USER_EMAIL','mikehankey@gmail.com');
define('SMTP_USER_Name','Mike Hankey');