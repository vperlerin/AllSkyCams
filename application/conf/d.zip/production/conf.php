<?

ini_set('display_errors', 'off');

// Require the database settings
//require('database.php');
 

define('MYSQL_DEBUG', false);

define ('DEV_OR_PROD', 'prod');
define ('SITE_URL','www.allskycams.com'); // Use for cookies on www.allskycams.org & allskycams.org

define ('BASE_URL', 'http://www.allskycams.com');
define ('ROOT_DIR', '/usr/sites/allskycams.com/AllSkyCams/');
define ('APP_DIR',  ROOT_DIR . '/application');
define ('HTDOCS_DIR', ROOT_DIR . '/htdocs');
 
// Turn logging on or off
define ('ENABLE_LOGGING', true);
define ('LOG_DIR', ROOT_DIR . '/logs');

// Cookie Variables
define ('COOKIE_EXPIRE', 31536000); 

// Memcache Settings
define ('MEMCACHE_ADDR', 'localhost');
define ('MEMCACHE_PORT', 11211);
 
// Add extra setup below
define ('SETUP', ROOT_DIR . 'application/conf/production/setup/');
require_once( SETUP ."smtp.php");
