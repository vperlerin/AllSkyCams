<?php
 
// SMTP
define('SMTP_HOST','smtp.gmail.com');
define('SMTP_USER','amsmeteors@gmail.com'); 
define('SMTP_PWD','$p@c31$c00l!');
define('SMTPSecure','tls');
define('SMTP_TLS_PORT','587');
define('SMTP_USER_EMAIL','amsmeteors@gmail.com');
define('SMTP_USER_Name','Mike Hankey');