<?php

class DBVars{
    static $db_config = array(
        'both'=>array(
            'dbserver'      => 'localhost',
            'dbname'        => 'ams_org',
            'dbuser'        => 'ams_user',
            'dbpassword'    => 'm3t30r1911'
        ),
		'wp'=>array(
            'dbserver'      => 'localhost',
            'dbname'        => 'ams_org',
            'dbuser'        => 'root',
            'dbpassword'    => 'Bl0wm369'
        )
    );
}
